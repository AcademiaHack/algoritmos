var i,j;

for (i=0; i<=6; i++){
	for (j=i; j<=6; j++){
		console.log(i+"|"+j);
	}	
}